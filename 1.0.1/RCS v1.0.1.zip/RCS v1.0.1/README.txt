RuneScape Community Script was developed by Sub-Zero (or, Moparscape: SRBuckey5266 and RuneLocus: Justin H).

http://www.rcscript.comlu.com for support, feedback, or concerns
========================================================================
==============================NOTICE====================================
========================================================================

You're allowed to remove the copyright in the footer, however please
do not re-publish RCS without my permission. Also, do not provide
direct download links.

Please make sure upon uploading RCS to your website, that you make sure
to go to the install directory to properly install RCS.

========================================================================
===========================CUSTOMIZATION================================
========================================================================

HOW TO ADD POST COUNT: Go into PhpMyAdmin or whatever your database
manager is, and click on the "config" table. Change "postcount" to 
1. 1 = on, 0 = off

You can also add recaptcha to your account creation page in includes/config.php

