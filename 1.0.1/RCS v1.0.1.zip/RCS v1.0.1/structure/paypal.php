<?php
/*
 * @PAYPAL IPN
 * ~~~~~~~~~~~~
 * @FILE DESCRIPTION: Donation managment/paypal processing
 * @LAST MODIFIED: June 5, 2012
 */

class Paypal_IPN
{
    
}

?>
